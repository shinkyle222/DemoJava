/**
 * 
 */
/**
 * @author user
 *
 */
module Quiz {
}