package day01;

/**
 * 2023-04-06
 * @author 홍길동
 */
public class Hello {
		
	public static void main(String[] args) {
		// \n은 줄바꿈입니다.
		/*
		여러줄 주석입니다.
		*/
		System.out.println("Hello...?");
		System.out.print("안녕하세요\n");
		System.out.print("반가워요");
			
	}
		
}
