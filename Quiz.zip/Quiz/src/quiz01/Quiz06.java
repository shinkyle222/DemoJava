package quiz01;

import java.util.Scanner;

public class Quiz06 {

	public static void main(String[] args) {
		/*
		 * if구문 밖에 선언된 변수를 잘 활용합니다.
		 * 
		 * 정수 3개를 입력을 받습니다.
		 * 가장 큰값, 중간값, 작은값을 구분해서 출력. (조건 - 같은 수는 없다 라고 가정)
		 * 
		 * 입력
		 * 15, 30, 7 -> max:30, mid:15, min:7
		 * 1, 2, 3 -> max:3, mid:2, min:1
		 * 
		 * 힌트
		 * a가 가장 클 때의 조건 (a > b && a > c)
		 * 
		 */
		int max = 0;
		int mid = 0;
		int min = 0;
		
		Scanner scan = new Scanner(System.in);
		
		
		
		
		
		
		
	}
}
